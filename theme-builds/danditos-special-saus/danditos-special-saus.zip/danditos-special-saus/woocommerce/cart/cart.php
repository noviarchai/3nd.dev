<?php
/**
 * Cart template
 *
 * @package Danditos_Special_Saus
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );
?>

<div class="page-header">
    <div class="container">
        <h1 class="page-title"><?php esc_html_e( 'Your Cart', 'danditos-special-saus' ); ?></h1>
    </div>
</div>

<section class="section" style="padding-top: var(--space-2xl);">
    <div class="container">
        <form action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">

            <div style="display: grid; grid-template-columns: 1fr 380px; gap: var(--space-2xl); align-items: start;">

                <!-- Cart Items -->
                <div class="woocommerce-cart-form">
                    <?php do_action( 'woocommerce_before_cart_table' ); ?>

                    <table class="shop_table shop_table_responsive cart" cellspacing="0">
                        <thead>
                            <tr>
                                <th class="product-remove">&nbsp;</th>
                                <th class="product-thumbnail">&nbsp;</th>
                                <th class="product-name"><?php esc_html_e( 'Product', 'danditos-special-saus' ); ?></th>
                                <th class="product-price"><?php esc_html_e( 'Price', 'danditos-special-saus' ); ?></th>
                                <th class="product-quantity"><?php esc_html_e( 'Quantity', 'danditos-special-saus' ); ?></th>
                                <th class="product-subtotal"><?php esc_html_e( 'Subtotal', 'danditos-special-saus' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php do_action( 'woocommerce_before_cart_contents' ); ?>

                            <?php
                            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                                $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                                $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

                                if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
                                    $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
                                    ?>
                                    <tr class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">

                                        <td class="product-remove">
                                            <?php
                                            echo apply_filters(
                                                'woocommerce_cart_item_remove_link',
                                                sprintf(
                                                    '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                                                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                                                    esc_html__( 'Remove this item', 'danditos-special-saus' ),
                                                    esc_attr( $product_id ),
                                                    esc_attr( $_product->get_sku() )
                                                ),
                                                $cart_item_key
                                            );
                                            ?>
                                        </td>

                                        <td class="product-thumbnail">
                                            <?php
                                            $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

                                            if ( ! $product_permalink ) {
                                                echo $thumbnail;
                                            } else {
                                                printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail );
                                            }
                                            ?>
                                        </td>

                                        <td class="product-name" data-title="<?php esc_attr_e( 'Product', 'danditos-special-saus' ); ?>">
                                            <?php
                                            if ( ! $product_permalink ) {
                                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );
                                            } else {
                                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() ), $cart_item, $cart_item_key ) );
                                            }

                                            do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

                                            echo wc_get_formatted_cart_item_data( $cart_item );

                                            if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
                                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'danditos-special-saus' ) . '</p>', $product_id ) );
                                            }
                                            ?>
                                        </td>

                                        <td class="product-price" data-title="<?php esc_attr_e( 'Price', 'danditos-special-saus' ); ?>">
                                            <?php
                                            echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
                                            ?>
                                        </td>

                                        <td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'danditos-special-saus' ); ?>">
                                            <?php
                                            if ( $_product->is_sold_individually() ) {
                                                $min_quantity = 1;
                                                $max_quantity = 1;
                                            } else {
                                                $min_quantity = 0;
                                                $max_quantity = $_product->get_max_purchase_quantity();
                                            }

                                            $product_quantity = woocommerce_quantity_input(
                                                array(
                                                    'input_name'   => "cart[{$cart_item_key}][qty]",
                                                    'input_value'   => $cart_item['quantity'],
                                                    'max_value'     => $max_quantity,
                                                    'min_value'     => $min_quantity,
                                                    'product_name'  => $_product->get_name(),
                                                ),
                                                $_product,
                                                false
                                            );

                                            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
                                            ?>
                                        </td>

                                        <td class="product-subtotal" data-title="<?php esc_attr_e( 'Subtotal', 'danditos-special-saus' ); ?>">
                                            <?php
                                            echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );
                                            ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>

                            <?php do_action( 'woocommerce_cart_contents' ); ?>

                            <tr>
                                <td colspan="6" class="actions">

                                    <?php if ( wc_coupons_enabled() ) { ?>
                                        <div class="coupon">
                                            <label for="coupon_code"><?php esc_html_e( 'Coupon:', 'danditos-special-saus' ); ?></label>
                                            <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'danditos-special-saus' ); ?>" />
                                            <button type="submit" class="button" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'danditos-special-saus' ); ?>"><?php esc_html_e( 'Apply coupon', 'danditos-special-saus' ); ?></button>
                                            <?php do_action( 'woocommerce_cart_coupon' ); ?>
                                        </div>
                                    <?php } ?>

                                    <button type="submit" class="button" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'danditos-special-saus' ); ?>"><?php esc_html_e( 'Update cart', 'danditos-special-saus' ); ?></button>

                                    <?php do_action( 'woocommerce_cart_actions' ); ?>

                                    <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
                                </td>
                            </tr>

                            <?php do_action( 'woocommerce_after_cart_contents' ); ?>
                        </tbody>
                    </table>
                    <?php do_action( 'woocommerce_after_cart_table' ); ?>
                </div>

                <!-- Cart Totals -->
                <div class="cart-collaterals">
                    <?php do_action( 'woocommerce_before_cart_collaterals' ); ?>

                    <div class="cart_totals <?php echo ( WC()->cart->get_cart_contents_count() == 0 ) ? 'cart-empty' : ''; ?>">
                        <h2><?php esc_html_e( 'Cart Totals', 'danditos-special-saus' ); ?></h2>

                        <table cellspacing="0" class="shop_table shop_table_responsive">
                            <tbody>
                                <tr class="cart-subtotal">
                                    <th><?php esc_html_e( 'Subtotal', 'danditos-special-saus' ); ?></th>
                                    <td data-title="<?php esc_attr_e( 'Subtotal', 'danditos-special-saus' ); ?>"><?php wc_cart_totals_subtotal_html(); ?></td>
                                </tr>

                                <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
                                    <tr class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                                        <th><?php wc_cart_totals_coupon_label( $coupon ); ?></th>
                                        <td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
                                    </tr>
                                <?php endforeach; ?>

                                <?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>
                                    <?php do_action( 'woocommerce_cart_totals_before_shipping' ); ?>
                                    <tr class="shipping">
                                        <th><?php esc_html_e( 'Shipping', 'danditos-special-saus' ); ?></th>
                                        <td data-title="<?php esc_attr_e( 'Shipping', 'danditos-special-saus' ); ?>"><?php woocommerce_shipping_calculator(); ?></td>
                                    </tr>
                                    <?php do_action( 'woocommerce_cart_totals_after_shipping' ); ?>
                                <?php endif; ?>

                                <?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
                                    <tr class="fee">
                                        <th><?php echo esc_html( $fee->name ); ?></th>
                                        <td><?php wc_cart_totals_fee_html( $fee ); ?></td>
                                    </tr>
                                <?php endforeach; ?>

                                <?php if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) : ?>
                                    <?php if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) : ?>
                                        <?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
                                            <tr class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                                                <th><?php echo esc_html( $tax->label ); ?></th>
                                                <td data-title="<?php echo esc_attr( $tax->label ); ?>"><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <tr class="tax-total">
                                            <th><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
                                            <td data-title="<?php echo esc_attr( WC()->countries->tax_or_vat() ); ?>"><?php wc_cart_totals_taxes_total_html(); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php do_action( 'woocommerce_cart_totals_before_order_total' ); ?>

                                <tr class="order-total">
                                    <th><?php esc_html_e( 'Total', 'danditos-special-saus' ); ?></th>
                                    <td data-title="<?php esc_attr_e( 'Total', 'danditos-special-saus' ); ?>"><?php wc_cart_totals_order_total_html(); ?></td>
                                </tr>

                                <?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>
                            </tbody>
                        </table>

                        <div class="wc-proceed-to-checkout">
                            <?php do_action( 'woocommerce_proceed_to_checkout' ); ?>
                        </div>

                        <?php do_action( 'woocommerce_after_cart_totals' ); ?>
                    </div>
                </div>

            </div>
        </form>

        <?php do_action( 'woocommerce_after_cart' ); ?>
    </div>
</section>

<?php get_footer(); ?>
